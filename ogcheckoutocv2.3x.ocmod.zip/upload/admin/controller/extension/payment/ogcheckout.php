<?php
class ControllerExtensionPaymentOgcheckout extends Controller {
	private $error = array();
	
	public function index() {
		$this->load->language('extension/payment/ogcheckout');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
		$this->request->post['ogcheckout_currency'] = $this->config->get('config_currency');
        if(isset($this->request->post['ogcheckout_payment_method_mode']) && isset($this->request->post['ogcheckout_customize_method']) && !empty($this->request->post['ogcheckout_customize_method'])){
        
			$mc = array();
			$mc = $this->request->post['ogcheckout_customize_method'];
			$this->request->post['ogcheckout_customize_method'] = json_encode($mc,true);
        }			
 
        $this->model_setting_setting->editSetting('ogcheckout', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true));
		}

		$data['button_configure'] = $this->url->link('extension/module/ogcheckout_button/configure', 'token=' . $this->session->data['token'], true);

		$data['token'] = $this->session->data['token'];
		
		// Heading
		$data['heading_title']          	   = $this->language->get('heading_title');	
		// Text
		$data['button_save']                   = $this->language->get('button_save');
		$data['button_cancel']                 = $this->language->get('button_cancel');
		$data['text_extension']		 		   = $this->language->get('text_extension');	
		$data['text_ogcheckout']				       = $this->language->get('text_ogcheckout');	
		$data['text_payment']				   = $this->language->get('text_payment');	
		$data['success']				   = $this->language->get('text_success');		 
		$data['text_edit']					   = $this->language->get('text_edit');	
		$data['text_currency']				   = $this->language->get('text_currency');	
		$data['text_yes']					   = $this->language->get('text_yes');	
		$data['text_no']					   = $this->language->get('text_no');	
		$data['text_unlink']		 		   = $this->language->get('text_unlink');
$data['text_enabled']		 		   = $this->language->get('text_enabled');
$data['text_disabled']		 		   = $this->language->get('text_disabled');		


		// Column

		$data['column_action']					 = $this->language->get('column_action');	
		$data['column_amount']					 = $this->language->get('column_amount');	
		$data['column_status']					 = $this->language->get('column_status');	
		$data['column_type']					 = $this->language->get('column_type');	
		$data['column_customer']				 = $this->language->get('column_customer');	
		$data['column_order']					 = $this->language->get('column_order');	
		$data['column_date_added']				 = $this->language->get('column_date_added');	

		// Entry
		$data['entry_checkout_title']		     = $this->language->get('entry_checkout_title');	
		$data['entry_checkout_description']	     = $this->language->get('entry_checkout_description');	
		$data['entry_status']                    = $this->language->get('entry_status');	
		$data['entry_merchant_name']			 = $this->language->get('entry_merchant_name');	
		$data['entry_auth_key']				     = $this->language->get('entry_auth_key');	
		$data['entry_secret_key']				 = $this->language->get('entry_secret_key');	
		$data['entry_callback_url']			     = $this->language->get('entry_callback_url');	
		$data['entry_endpoint_url']              = $this->language->get('entry_endpoint_url');	
		$data['entry_ogcheckout_country']			 = $this->language->get('entry_ogcheckout_country');	
		$data['entry_ogcheckout_language']			 = $this->language->get('entry_ogcheckout_language');	
		$data['entry_ogcheckout_tunnel']			     = $this->language->get('entry_ogcheckout_tunnel');	
		$data['entry_ogcheckout_currency']			 = $this->language->get('entry_ogcheckout_currency');	
		$data['entry_payment_method']            = $this->language->get('entry_payment_method');	
		$data['entry_channel_code']              = $this->language->get('entry_channel_code');	
		$data['entry_currency_code']             = $this->language->get('entry_currency_code');	
		$data['entry_customize_payment_form']    = $this->language->get('entry_customize_payment_form');	
		$data['entry_ogcheckout_payment_form']        = $this->language->get('entry_ogcheckout_payment_form');	
		$data['entry_payment_currency']          = $this->language->get('entry_payment_currency');		

$data['entry_checkout_title_placeholder']=$this->language->get('entry_checkout_title_placeholder');	
$data['entry_checkout_description_placeholder']=$this->language->get('entry_checkout_description_placeholder');
		$data['entry_ogcheckout_language_placeholder']		 = $this->language->get('entry_ogcheckout_language_placeholder');
		$data['entry_ogcheckout_ogpayment_placeholder']		 = $this->language->get('entry_ogcheckout_ogpayment_placeholder');

		$data['error_ogcheckout_merchant_name']		= $this->language->get('error_ogcheckout_merchant_name');
		$data['error_ogcheckout_auth_key']	      = $this->language->get('text_eerror_ogcheckout_auth_keyxtension');
		$data['error_ogcheckout_secret_key']     = $this->language->get('error_ogcheckout_secret_key');
		$data['error_ogcheckout_endpoint_url']	 = $this->language->get('error_ogcheckout_endpoint_url');
		$data['error_ogcheckout_currency']	 = $this->language->get('error_ogcheckout_currency');
		$data['error_ogcheckout_language']  = $this->language->get('error_ogcheckout_language');
		$data['error_ogcheckout_payment_method_mode']  = $this->language->get('error_ogcheckout_payment_method_mode');
		$data['error_ogcheckout_customizemethod']   = $this->language->get('error_ogcheckout_customizemethod');
		$data['error_ogcheckout_ogpaymentmethod']     = $this->language->get('error_ogcheckout_ogpaymentmethod');
			
		// Tab
		$data['tab_general']        = $this->language->get('tab_general');
		$data['keys_url_section']        = $this->language->get('keys_url_section');
		$data['payment_method_configuration']      = $this->language->get('payment_method_configuration');
		$data['default_configuration']             = $this->language->get('default_configuration');
		$data['tab_config']					             = $this->language->get('tab_config');
		$data['tab_order_status']				         = $this->language->get('tab_order_status');
		$data['tab_paymentconfig']				         = $this->language->get('tab_paymentconfig');
		$data['tab_paymentchannelconfig']		         = $this->language->get('tab_paymentchannelconfig');

		// Help
		$data['help_callback_url']		   = $this->language->get('help_callback_url');
		$data['help_customize_method']	   = $this->language->get('help_customize_method');	
		$data['help_ogpayment_method']	   = $this->language->get('help_ogpayment_method');
		$data['help_ogpayment_currency']   = $this->language->get('help_ogpayment_currency');
		$data['help_language']		       = $this->language->get('help_language');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['account'])) {
			$data['error_account'] = $this->error['account'];
		} else {
			$data['error_account'] = array();
		}
		
		if (isset($this->error['merchantname'])) {
			$data['error_merchantname'] = $this->error['merchantname'];
		} else {
			$data['error_merchantname'] = '';
		}
		if (isset($this->error['authkey'])) {
			$data['error_authkey'] = $this->error['authkey'];
		} else {
			$data['error_authkey'] = '';
		}
		if (isset($this->error['secretkey'])) {
			$data['error_secretkey'] = $this->error['secretkey'];
		} else {
			$data['error_secretkey'] = '';
		}
		if (isset($this->error['endpointurl'])) {
			$data['error_endpointurl'] = $this->error['endpointurl'];
		} else {
			$data['error_endpointurl'] = '';
		}

		if (isset($this->error['language'])) {
			$data['error_language'] = $this->error['language'];
		} else {
			$data['error_language'] = '';
		}
		
		if (isset($this->error['customizemethod'])) {
			$data['error_customizemethod'] = $this->error['customizemethod'];
		} else {
			$data['error_customizemethod'] = '';
		}	

		if (isset($this->error['ogpaymentmethod'])) {
			$data['error_ogpaymentmethod'] = $this->error['ogpaymentmethod'];
		} else {
			$data['error_ogpaymentmethod'] = '';
		}		

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/ogcheckout', 'token=' . $this->session->data['token'], true)
		);

		$data['action'] = $this->url->link('extension/payment/ogcheckout', 'token=' . $this->session->data['token'], true);

		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true);
		
		$data['tab_general'] = $this->language->get('tab_general');
		
		// Genral Settings
		if (isset($this->request->post['ogcheckout_checkout_title'])) {
			$data['ogcheckout_checkout_title'] = $this->request->post['ogcheckout_checkout_title'];
		} else {
			$data['ogcheckout_checkout_title'] = $this->config->get('ogcheckout_checkout_title');
		}
		if (isset($this->request->post['ogcheckout_checkout_description'])) {
			$data['ogcheckout_checkout_description'] = $this->request->post['ogcheckout_checkout_description'];
		} else {
			$data['ogcheckout_checkout_description'] = $this->config->get('ogcheckout_checkout_description');
		}
		if (isset($this->request->post['ogcheckout_status'])) {
			$data['ogcheckout_status'] = $this->request->post['ogcheckout_status'];
		} else {
			$data['ogcheckout_status'] = $this->config->get('ogcheckout_status');
		}		
		
		// Configuration
		if (isset($this->request->post['ogcheckout_merchant_name'])) {
			$data['ogcheckout_merchant_name'] = $this->request->post['ogcheckout_merchant_name'];
		} else {
			$data['ogcheckout_merchant_name'] = $this->config->get('ogcheckout_merchant_name');
		}
		if (isset($this->request->post['ogcheckout_auth_key'])) {
			$data['ogcheckout_auth_key'] = $this->request->post['ogcheckout_auth_key'];
		} else {
			$data['ogcheckout_auth_key'] = $this->config->get('ogcheckout_auth_key');
		}
		if (isset($this->request->post['ogcheckout_secret_key'])) {
			$data['ogcheckout_secret_key'] = $this->request->post['ogcheckout_secret_key'];
		} else {
			$data['ogcheckout_secret_key'] = $this->config->get('ogcheckout_secret_key');
		}
		
		if (isset($this->request->post['ogcheckout_endpoint_url'])) {
			$data['ogcheckout_endpoint_url'] = $this->request->post['ogcheckout_endpoint_url'];
		} else {
			$data['ogcheckout_endpoint_url'] = $this->config->get('ogcheckout_endpoint_url');
		}
		
		if (isset($this->request->post['ogcheckout_callback_url'])) {
			$data['ogcheckout_callback_url'] = $this->request->post['ogcheckout_callback_url'];
		} else {
			$data['ogcheckout_callback_url'] = $this->config->get('ogcheckout_callback_url');
		}


		// Payment Configuration
		$data['ogcheckout_currency'] = $this->config->get('config_currency');

		if (isset($this->request->post['ogcheckout_language'])) {
			$data['ogcheckout_language'] = $this->request->post['ogcheckout_language'];
		} else {
			$data['ogcheckout_language'] = $this->config->get('ogcheckout_language');
		}
		if (isset($this->request->post['ogcheckout_tunnel'])) {
			$data['ogcheckout_tunnel'] = $this->request->post['ogcheckout_tunnel'];
		} else {
			$data['ogcheckout_tunnel'] = $this->config->get('ogcheckout_tunnel');
		}

        //Payment channels Configuration
		if (isset($this->request->post['ogcheckout_payment_method_mode'])) {
			$data['ogcheckout_payment_method_mode'] = $this->request->post['ogcheckout_payment_method_mode'];
		} elseif(!empty($this->config->get('ogcheckout_payment_method_mode'))) {
			$data['ogcheckout_payment_method_mode'] = $this->config->get('ogcheckout_payment_method_mode');
		}else{
		    $data['ogcheckout_payment_method_mode'] = 'customize';
		}	
		    $data['ogcheckout_ogpayment_name'] = '';
		    $data['ogcheckout_ogpayment_currency'] = '';
        if(isset($this->request->post['ogcheckout_payment_method_mode']) && $this->request->post['ogcheckout_payment_method_mode']=="ogpayment"){
			if (isset($this->request->post['ogcheckout_ogpayment_name'])) {
				$data['ogcheckout_ogpayment_name'] = $this->request->post['ogcheckout_ogpayment_name'];
			} else {
				$data['ogcheckout_ogpayment_name'] = $this->config->get('ogcheckout_ogpayment_name');
			}
			if (isset($this->request->post['ogcheckout_ogpayment_currency'])) {
				$data['ogcheckout_ogpayment_currency'] = $this->request->post['ogcheckout_ogpayment_currency'];
			} else {
				$data['ogcheckout_ogpayment_currency'] = $this->config->get('ogcheckout_ogpayment_currency');
			}			
        }elseif($this->config->get('ogcheckout_payment_method_mode')){
                if($this->config->get('ogcheckout_ogpayment_name')){
    			   $data['ogcheckout_ogpayment_name'] = $this->config->get('ogcheckout_ogpayment_name');
                }else{
                   $data['ogcheckout_ogpayment_name'] = ''; 
                }
                
                if($this->config->get('ogcheckout_ogpayment_currency')){
    			   $data['ogcheckout_ogpayment_currency'] = $this->config->get('ogcheckout_ogpayment_currency');
                }else{
                   $data['ogcheckout_ogpayment_currency'] = ''; 
                }
                
	   }
		$data['customize_methods']=array();
        if(isset($this->request->post['ogcheckout_payment_method_mode']) && $this->request->post['ogcheckout_payment_method_mode']=="customize"){
            if(isset($this->request->post['ogcheckout_customize_method'])){
    			$data['customize_methods'] = array();
    			$data['customize_methods'] = $this->request->post['ogcheckout_customize_method'];
    		}else{
    			$data['customize_methods'] = array();
    			$data['customize_methods'] = json_decode($this->config->get('ogcheckout_customize_method'),true);		    
    		}	
	   }elseif($this->config->get('ogcheckout_payment_method_mode')){

    			$data['customize_methods'] = array();
    			$data['customize_methods'] = json_decode($this->config->get('ogcheckout_customize_method'),true);
	   }

		if (isset($this->request->post['ogcheckout_status'])) {
			$data['ogcheckout_status'] = $this->request->post['ogcheckout_status'];
		} else {
			$data['ogcheckout_status'] = $this->config->get('ogcheckout_status');
		}
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/ogcheckout', $data));
	}

	public function install() {
		$this->load->model('setting/setting');
        $this->load->model('extension/payment/ogcheckout');
		$defaults = array();

		// Genral Settings
		$defaults['ogcheckout_checkout_title'] = "";
		$defaults['ogcheckout_checkout_description'] = "";
		
		// Configuration
		$defaults['ogcheckout_merchant_name'] = "";
		$defaults['ogcheckout_auth_key'] = "";
		$defaults['ogcheckout_secret_key'] = "";
		$defaults['ogcheckout_endpoint_url'] = "";
		$defaults['ogcheckout_callback_url'] = "";

		// Payment Configuration
		$defaults['ogcheckout_currency'] = $this->config->get('config_currency');
		$defaults['ogcheckout_language'] = "en";
		$defaults['ogcheckout_tunnel'] = "";

        //Payment channels Configuration
		$defaults['ogcheckout_payment_method_mode'] = "customize";
		$defaults['ogcheckout_customize_method'] = "";
		$defaults['ogcheckout_ogpayment_method'] = "";        
		
		$this->model_setting_setting->editSetting('ogcheckout', $defaults);
		$this->model_extension_payment_ogcheckout->addColumn();
	}
	
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/paypoint')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
        
		if (!$this->request->post['ogcheckout_merchant_name']) {
			$this->error['merchantname'] = $this->language->get('error_ogcheckout_merchant_name');
		}
		if (!$this->request->post['ogcheckout_auth_key']) {
			$this->error['authkey'] = $this->language->get('error_ogcheckout_auth_key');
		}
		if (!$this->request->post['ogcheckout_secret_key']) {
			$this->error['secretkey'] = $this->language->get('error_ogcheckout_secret_key');
		}
		if (!$this->request->post['ogcheckout_endpoint_url']) {
			$this->error['endpointurl'] = $this->language->get('error_ogcheckout_endpoint_url');
		}
		if (!$this->request->post['ogcheckout_language']) {
			$this->error['language'] = $this->language->get('error_ogcheckout_language');
		}
		if (isset($this->request->post['ogcheckout_payment_method_mode'])) {
            if($this->request->post['ogcheckout_payment_method_mode']=='customize'){
			  if(isset($this->request->post['ogcheckout_customize_method'])){
                
				foreach($this->request->post['ogcheckout_customize_method'] as $key=>$value){
					if(empty($value['name'])){
					   $this->error['customizemethod'] = $this->language->get('error_ogcheckout_customizemethod');
					}
					if(empty($value['code'])){
					   $this->error['customizemethod'] = $this->language->get('error_ogcheckout_customizemethod');						
					}
					if(empty($value['currency'])){
					   $this->error['customizemethod'] = $this->language->get('error_ogcheckout_customizemethod');						
					}					
				}
			  }else{
					   $this->error['customizemethod'] = $this->language->get('error_ogcheckout_customizemethod');
			  }
			}
            if($this->request->post['ogcheckout_payment_method_mode']=='ogpayment'){
				if(!$this->request->post['ogcheckout_ogpayment_name']){
					$this->error['ogpaymentmethod'] = $this->language->get('error_ogcheckout_ogpaymentmethod');					
				}				
            }				
			
		}		
		
		return !$this->error;
	}

}
