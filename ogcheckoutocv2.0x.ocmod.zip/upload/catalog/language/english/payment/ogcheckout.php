<?php
// Heading
$_['default_title']					 = 'Og Checkout';
$_['default_description']			 = 'You will be redirect to Og Checkout Secure page';
?>