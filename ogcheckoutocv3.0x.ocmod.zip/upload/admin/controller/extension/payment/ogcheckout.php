<?php
class ControllerExtensionPaymentOgcheckout extends Controller {
	private $error = array();
	
	public function index() {
		$this->load->language('extension/payment/ogcheckout');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
		$this->request->post['payment_ogcheckout_currency'] = $this->config->get('config_currency');
        if(isset($this->request->post['payment_ogcheckout_payment_method_mode']) && isset($this->request->post['payment_ogcheckout_customize_method']) && !empty($this->request->post['payment_ogcheckout_customize_method'])){
        
			$mc = array();
			$mc = $this->request->post['payment_ogcheckout_customize_method'];
			$this->request->post['payment_ogcheckout_customize_method'] = json_encode($mc,true);
        }			
 
        $this->model_setting_setting->editSetting('payment_ogcheckout', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		$data['button_configure'] = $this->url->link('extension/module/ogcheckout_button/configure', 'user_token=' . $this->session->data['user_token'], true);

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['account'])) {
			$data['error_account'] = $this->error['account'];
		} else {
			$data['error_account'] = array();
		}
		
		if (isset($this->error['merchantname'])) {
			$data['error_merchantname'] = $this->error['merchantname'];
		} else {
			$data['error_merchantname'] = '';
		}
		if (isset($this->error['authkey'])) {
			$data['error_authkey'] = $this->error['authkey'];
		} else {
			$data['error_authkey'] = '';
		}
		if (isset($this->error['secretkey'])) {
			$data['error_secretkey'] = $this->error['secretkey'];
		} else {
			$data['error_secretkey'] = '';
		}
		if (isset($this->error['endpointurl'])) {
			$data['error_endpointurl'] = $this->error['endpointurl'];
		} else {
			$data['error_endpointurl'] = '';
		}

		if (isset($this->error['language'])) {
			$data['error_language'] = $this->error['language'];
		} else {
			$data['error_language'] = '';
		}
		
		if (isset($this->error['customizemethod'])) {
			$data['error_customizemethod'] = $this->error['customizemethod'];
		} else {
			$data['error_customizemethod'] = '';
		}	

		if (isset($this->error['ogpaymentmethod'])) {
			$data['error_ogpaymentmethod'] = $this->error['ogpaymentmethod'];
		} else {
			$data['error_ogpaymentmethod'] = '';
		}		

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/ogcheckout', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/payment/ogcheckout', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);
		
		$data['tab_general'] = $this->language->get('tab_general');
		
		// Configuration
		if (isset($this->request->post['payment_ogcheckout_merchant_name'])) {
			$data['payment_ogcheckout_merchant_name'] = $this->request->post['payment_ogcheckout_merchant_name'];
		} else {
			$data['payment_ogcheckout_merchant_name'] = $this->config->get('payment_ogcheckout_merchant_name');
		}
		if (isset($this->request->post['payment_ogcheckout_auth_key'])) {
			$data['payment_ogcheckout_auth_key'] = $this->request->post['payment_ogcheckout_auth_key'];
		} else {
			$data['payment_ogcheckout_auth_key'] = $this->config->get('payment_ogcheckout_auth_key');
		}
		if (isset($this->request->post['payment_ogcheckout_secret_key'])) {
			$data['payment_ogcheckout_secret_key'] = $this->request->post['payment_ogcheckout_secret_key'];
		} else {
			$data['payment_ogcheckout_secret_key'] = $this->config->get('payment_ogcheckout_secret_key');
		}
		
		if (isset($this->request->post['payment_ogcheckout_endpoint_url'])) {
			$data['payment_ogcheckout_endpoint_url'] = $this->request->post['payment_ogcheckout_endpoint_url'];
		} else {
			$data['payment_ogcheckout_endpoint_url'] = $this->config->get('payment_ogcheckout_endpoint_url');
		}
		
		if (isset($this->request->post['payment_ogcheckout_callback_url'])) {
			$data['payment_ogcheckout_callback_url'] = $this->request->post['payment_ogcheckout_callback_url'];
		} else {
			$data['payment_ogcheckout_callback_url'] = $this->config->get('payment_ogcheckout_callback_url');
		}
		if (isset($this->request->post['payment_ogcheckout_status'])) {
			$data['payment_ogcheckout_status'] = $this->request->post['payment_ogcheckout_status'];
		} else {
			$data['payment_ogcheckout_status'] = $this->config->get('payment_ogcheckout_status');
		}

		// Payment Configuration
		$data['payment_ogcheckout_currency'] = $this->config->get('config_currency');
		if (isset($this->request->post['payment_ogcheckout_language'])) {
			$data['payment_ogcheckout_language'] = $this->request->post['payment_ogcheckout_language'];
		} else {
			$data['payment_ogcheckout_language'] = $this->config->get('payment_ogcheckout_language');
		}
		if (isset($this->request->post['payment_ogcheckout_tunnel'])) {
			$data['payment_ogcheckout_tunnel'] = $this->request->post['payment_ogcheckout_tunnel'];
		} else {
			$data['payment_ogcheckout_tunnel'] = $this->config->get('payment_ogcheckout_tunnel');
		}

        //Payment channels Configuration
		if (isset($this->request->post['payment_ogcheckout_payment_method_mode'])) {
			$data['payment_ogcheckout_payment_method_mode'] = $this->request->post['payment_ogcheckout_payment_method_mode'];
		} elseif(!empty($this->config->get('payment_ogcheckout_payment_method_mode'))) {
			$data['payment_ogcheckout_payment_method_mode'] = $this->config->get('payment_ogcheckout_payment_method_mode');
		}else{
		    $data['payment_ogcheckout_payment_method_mode'] = 'customize';
		}	

        if(isset($this->request->post['payment_ogcheckout_payment_method_mode']) && $this->request->post['payment_ogcheckout_payment_method_mode']=="ogpayment"){
			if (isset($this->request->post['payment_ogcheckout_ogpayment_name'])) {
				$data['payment_ogcheckout_ogpayment_name'] = $this->request->post['payment_ogcheckout_ogpayment_name'];
			} else {
				$data['payment_ogcheckout_ogpayment_name'] = $this->config->get('payment_ogcheckout_ogpayment_name');
			}
			if (isset($this->request->post['payment_ogcheckout_ogpayment_currency'])) {
				$data['payment_ogcheckout_ogpayment_currency'] = $this->request->post['payment_ogcheckout_ogpayment_currency'];
			} else {
				$data['payment_ogcheckout_ogpayment_currency'] = $this->config->get('payment_ogcheckout_ogpayment_currency');
			}			
        }elseif($this->config->get('payment_ogcheckout_payment_method_mode')){
                if($this->config->get('payment_ogcheckout_ogpayment_name')){
    			   $data['payment_ogcheckout_ogpayment_name'] = $this->config->get('payment_ogcheckout_ogpayment_name');
                }else{
                   $data['payment_ogcheckout_ogpayment_name'] = ''; 
                }
                
                if($this->config->get('payment_ogcheckout_ogpayment_currency')){
    			   $data['payment_ogcheckout_ogpayment_currency'] = $this->config->get('payment_ogcheckout_ogpayment_currency');
                }else{
                   $data['payment_ogcheckout_ogpayment_currency'] = ''; 
                }
                
	   }
		
        if(isset($this->request->post['payment_ogcheckout_payment_method_mode']) && $this->request->post['payment_ogcheckout_payment_method_mode']=="customize"){
            if(isset($this->request->post['payment_ogcheckout_customize_method'])){
    			$data['customize_methods'] = array();
    			$data['customize_methods'] = $this->request->post['payment_ogcheckout_customize_method'];
    		}else{
    			$data['customize_methods'] = array();
    			$data['customize_methods'] = json_decode($this->config->get('payment_ogcheckout_customize_method'),true);		    
    		}	
	   }elseif($this->config->get('payment_ogcheckout_payment_method_mode')){

    			$data['customize_methods'] = array();
    			$data['customize_methods'] = json_decode($this->config->get('payment_ogcheckout_customize_method'),true);
	   }

		if (isset($this->request->post['payment_ogcheckout_status'])) {
			$data['payment_ogcheckout_status'] = $this->request->post['payment_ogcheckout_status'];
		} else {
			$data['payment_ogcheckout_status'] = $this->config->get('payment_ogcheckout_status');
		}
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/ogcheckout', $data));
	}

	public function install() {
		$this->load->model('setting/setting');
        $this->load->model('extension/payment/ogcheckout');
		$defaults = array();

		// Genral Settings
		$defaults['payment_ogcheckout_checkout_title'] = "";
		$defaults['payment_ogcheckout_checkout_description'] = "";
		
		// Configuration
		$defaults['payment_ogcheckout_merchant_name'] = "";
		$defaults['payment_ogcheckout_auth_key'] = "";
		$defaults['payment_ogcheckout_secret_key'] = "";
		$defaults['payment_ogcheckout_endpoint_url'] = "";
		$defaults['payment_ogcheckout_callback_url'] = "";

		// Payment Configuration
		$defaults['payment_ogcheckout_currency'] = $this->config->get('config_currency');
		$defaults['payment_ogcheckout_language'] = "en";
		$defaults['payment_ogcheckout_tunnel'] = "";

        //Payment channels Configuration
		$defaults['payment_ogcheckout_payment_method_mode'] = "customize";
		$defaults['payment_ogcheckout_customize_method'] = "";
		$defaults['payment_ogcheckout_ogpayment_method'] = "";        
		
		$this->model_setting_setting->editSetting('payment_ogcheckout', $defaults);
		$this->model_extension_payment_ogcheckout->addColumn();
	}
	
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/paypoint')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
        
		if (!$this->request->post['payment_ogcheckout_merchant_name']) {
			$this->error['merchantname'] = $this->language->get('error_ogcheckout_merchant_name');
		}
		if (!$this->request->post['payment_ogcheckout_auth_key']) {
			$this->error['authkey'] = $this->language->get('error_ogcheckout_auth_key');
		}
		if (!$this->request->post['payment_ogcheckout_secret_key']) {
			$this->error['secretkey'] = $this->language->get('error_ogcheckout_secret_key');
		}
		if (!$this->request->post['payment_ogcheckout_endpoint_url']) {
			$this->error['endpointurl'] = $this->language->get('error_ogcheckout_endpoint_url');
		}
		if (!$this->request->post['payment_ogcheckout_language']) {
			$this->error['language'] = $this->language->get('error_ogcheckout_language');
		}
		if (isset($this->request->post['payment_ogcheckout_payment_method_mode'])) {
            if($this->request->post['payment_ogcheckout_payment_method_mode']=='customize'){
			  if(isset($this->request->post['payment_ogcheckout_customize_method'])){
                
				foreach($this->request->post['payment_ogcheckout_customize_method'] as $key=>$value){
					if(empty($value['name'])){
					   $this->error['customizemethod'] = $this->language->get('error_ogcheckout_customizemethod');
					}
					if(empty($value['code'])){
					   $this->error['customizemethod'] = $this->language->get('error_ogcheckout_customizemethod');						
					}
					if(empty($value['currency'])){
					   $this->error['customizemethod'] = $this->language->get('error_ogcheckout_customizemethod');						
					}					
				}
			  }else{
					   $this->error['customizemethod'] = $this->language->get('error_ogcheckout_customizemethod');
			  }
			}
            if($this->request->post['payment_ogcheckout_payment_method_mode']=='ogpayment'){
				if(!$this->request->post['payment_ogcheckout_ogpayment_name']){
					$this->error['ogpaymentmethod'] = $this->language->get('error_ogcheckout_ogpaymentmethod');					
				}				
            }				
			
		}		
		
		return !$this->error;
	}

}
